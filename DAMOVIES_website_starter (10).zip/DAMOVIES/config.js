/* DAMOVIES configuration
   To enable real admin login and permanent film storage, create a free Supabase project.
   Paste the Project URL and anon/public key below. Never put a service_role key here.
*/
window.DAMOVIES_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};