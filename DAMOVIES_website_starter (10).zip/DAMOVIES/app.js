(() => {
const $ = id => document.getElementById(id);
const cfg = window.DAMOVIES_CONFIG || {};
let supabase = null, session = null, isAdmin = false, currentGenre = "All", lang = "rw";
let films = [];
const demoFilms = [];
const text = (rw,en) => lang === "rw" ? rw : en;
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),3000)}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function configured(){return !!(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY && window.supabase)}
function openModal(id){$(id).classList.remove("hidden")}
function closeModal(id){$(id).classList.add("hidden")}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.close)));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.add("hidden")}));
$("year").textContent=new Date().getFullYear();
if(configured()){supabase=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);initBackend()} else {films=JSON.parse(localStorage.getItem("damovies_demo_films")||"[]");render()}
async function initBackend(){
 const {data}=await supabase.auth.getSession();session=data.session;
 supabase.auth.onAuthStateChange((_event,s)=>{session=s;refreshAdmin();loadFilms()});
 await refreshAdmin();await loadFilms();
}
async function refreshAdmin(){
 isAdmin=false;
 if(session&&supabase){const {data}=await supabase.from("admins").select("user_id").eq("user_id",session.user.id).maybeSingle();isAdmin=!!data}
}
async function loadFilms(){
 if(!supabase){render();return}
 const {data,error}=await supabase.from("films").select("*").eq("published",true).order("created_at",{ascending:false});
 if(error){toast("Database: "+error.message);films=[]}else films=data||[];
 render();
}
function render(){
 const q=$("searchInput").value.trim().toLowerCase(), type=$("typeFilter").value;
 const filtered=films.filter(f=>(currentGenre==="All"||f.genre===currentGenre)&& (type==="All"||f.kind===type) && (!q||`${f.title} ${f.title_en||""} ${f.description||""} ${f.genre||""}`.toLowerCase().includes(q)));
 $("movieGrid").innerHTML=filtered.map(f=>`<article class="movie-card" data-id="${esc(f.id)}"><div class="poster">${f.poster_url?`<img loading="lazy" src="${esc(f.poster_url)}" alt="${esc(f.title)}" onerror="this.style.display='none'">`:`<span class="poster-fallback">D</span>`}<span class="type-tag">${f.kind==="Series"?"SERIES":"MOVIE"}</span><div class="play"><span>▶</span></div></div><div class="movie-title">${esc(lang==="en"?(f.title_en||f.title):f.title)}</div><div class="movie-meta"><span>${esc(f.year||"—")} · ${esc(f.genre||"Drama")}</span><span class="rating">★ ${esc(f.rating||"—")}</span></div></article>`).join("");
 $("emptyState").style.display=filtered.length?"none":"block";
 document.querySelectorAll(".movie-card").forEach(card=>card.addEventListener("click",()=>showFilm(card.dataset.id)));
}
document.querySelectorAll(".genre").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".genre").forEach(x=>x.classList.remove("active"));b.classList.add("active");currentGenre=b.dataset.genre;render()}));
$("searchInput").addEventListener("input",render);$("searchBtn").addEventListener("click",render);$("typeFilter").addEventListener("change",render);
$("langBtn").addEventListener("click",()=>{lang=lang==="rw"?"en":"rw";$("langBtn").textContent=lang==="rw"?"EN":"RW";document.documentElement.lang=lang;document.querySelectorAll("[data-rw][data-en]").forEach(el=>{el.innerHTML=el.dataset[lang]});$("searchInput").placeholder=text("Shaka filime cyangwa series...","Search movies or series...");document.querySelectorAll(".genre").forEach(b=>{if(b.dataset.genre==="All")b.textContent=text("Byose","All")});render()});
async function showFilm(id){
 const f=films.find(x=>String(x.id)===String(id));if(!f)return;
 const title=lang==="en"?(f.title_en||f.title):f.title;
 const video=videoEmbed(f.video_url||"");
 $("watchBody").innerHTML=`<h2>${esc(title)}</h2><p>${esc(f.year||"")} · ${esc(f.genre||"")} · ${esc(f.kind||"Movie")}</p><div class="watch-video">${video||`<div style="height:100%;display:grid;place-items:center;color:#aaa;padding:20px;text-align:center">Video link has not been added yet.</div>`}</div><p>${esc(f.description||"")}</p>${isAdmin?`<button class="secondary danger" id="deleteFilm">Delete this title</button>`:""}`;
 openModal("watchModal");
 if(isAdmin&&$("deleteFilm"))$("deleteFilm").onclick=()=>deleteFilm(f.id);
}
function videoEmbed(url){
 if(!url)return "";
 try{const u=new URL(url);if(u.hostname.includes("youtube.com")||u.hostname==="youtu.be"){let id=u.hostname==="youtu.be"?u.pathname.slice(1):u.searchParams.get("v");if(u.pathname.includes("/embed/"))id=u.pathname.split("/embed/")[1];return id?`<iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}" allowfullscreen title="Video player"></iframe>`:""}if(u.hostname.includes("vimeo.com")){const id=u.pathname.split("/").filter(Boolean).pop();return `<iframe src="https://player.vimeo.com/video/${encodeURIComponent(id)}" allowfullscreen title="Video player"></iframe>`}if(/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)||url.includes("/storage/v1/object/public/"))return `<video controls playsinline src="${esc(url)}"></video>`;return `<video controls playsinline src="${esc(url)}"></video>`}catch(e){return ""}
}
$("adminOpen").addEventListener("click",()=>{renderAdmin();openModal("adminModal")});
function renderAdmin(){
 const connected=configured();
 if(!connected){$("adminBody").innerHTML=`<h2>DAMOVIES Admin</h2><p>Admin panel izakora neza umaze guhuza urubuga na Supabase. Ubu urimo kureba uburyo bwo kugerageza (demo).</p><div class="admin-status">Backend: ${connected?"Connected":"Not configured"} · Demo mode ibika amakuru muri browser yawe gusa.</div><div class="field"><label>Demo Admin PIN</label><input id="demoPin" type="password" placeholder="Andika 1234"></div><div class="form-actions"><button class="primary-full" id="demoLogin">Komeza muri demo</button></div><p class="hint">Iyi PIN ni iya demo gusa, si umutekano wa website iri kuri internet. Ntukoreshe demo mode mu makuru nyayo.</p>`;$("demoLogin").onclick=()=>{if($("demoPin").value==="1234"){isAdmin=true;renderAdminPanel()}else toast("PIN si yo. Demo PIN ni 1234.")};return}
 if(!session){$("adminBody").innerHTML=`<h2>Kwinjira kwa Admin</h2><p>Injira ukoresheje email yemerewe kuba Admin.</p><div class="field"><label>Email</label><input id="adminEmail" type="email" autocomplete="username" placeholder="admin@example.com"></div><div class="field"><label>Password</label><input id="adminPassword" type="password" autocomplete="current-password" placeholder="Password"></div><div class="form-actions"><button class="primary-full" id="loginBtn">Injira</button></div><p class="hint">Konti ya Admin uyikora muri Supabase Authentication, hanyuma ukongeramo user ID muri admins table.</p>`;$("loginBtn").onclick=login;return}
 if(!isAdmin){$("adminBody").innerHTML=`<h2>Nta burenganzira bwa Admin</h2><p>Konti winjiyemo ntiri ku rutonde rwa Admin.</p><button class="secondary" id="logoutBtn">Sohoka</button>`;$("logoutBtn").onclick=logout;return}
 renderAdminPanel();
}
async function login(){const email=$("adminEmail").value.trim(),password=$("adminPassword").value;const {error}=await supabase.auth.signInWithPassword({email,password});if(error){toast(error.message);return}await refreshAdmin();renderAdmin();if(isAdmin)toast("Winjiye neza")}
async function logout(){await supabase.auth.signOut();session=null;isAdmin=false;renderAdmin();toast("Wasohotse")}
function renderAdminPanel(){
 $("adminBody").innerHTML=`<h2>Admin dashboard</h2><p>Ongeramo filime, hindura amakuru cyangwa usibe izitari ngombwa.</p><form id="filmForm"><div class="field"><label>Izina ryayo (Kinyarwanda)</label><input name="title" required maxlength="160"></div><div class="field"><label>Title (English, optional)</label><input name="title_en" maxlength="160"></div><div class="field"><label>Ibisobanuro</label><textarea name="description"></textarea></div><div class="field"><label>Poster image URL</label><input name="poster_url" type="url" placeholder="https://..."></div><div class="field"><label>Video URL (MP4, YouTube, Vimeo, cyangwa public link)</label><input name="video_url" type="url" required placeholder="https://..."></div><div class="field"><label>Ubwoko</label><select name="kind"><option>Movie</option><option>Series</option></select></div><div class="field"><label>Genre</label><select name="genre"><option>Action</option><option>Drama</option><option>Comedy</option><option>Romance</option><option>Thriller</option><option>Horror</option><option>Adventure</option><option>Crime</option><option>Documentary</option></select></div><div class="field"><label>Umwaka</label><input name="year" type="number" min="1900" max="2100"></div><div class="field"><label>Rating (optional)</label><input name="rating" type="number" min="0" max="10" step=".1"></div><div class="form-actions"><button class="primary-full" type="submit">Bika filime</button><button class="secondary" type="button" id="logoutBtn">Sohoka</button></div></form><p class="hint">Iyi version ibika amakuru n'amalink; upload ya video nini isaba video hosting cyangwa Supabase Storage. Ntushyireho filime udafitiye uburenganzira.</p>`;
 $("filmForm").onsubmit=saveFilm;$("logoutBtn").onclick=logout;
}
async function saveFilm(e){
 e.preventDefault();const fd=new FormData(e.target);const row={title:fd.get("title").trim(),title_en:fd.get("title_en").trim()||null,description:fd.get("description").trim()||null,poster_url:fd.get("poster_url").trim()||null,video_url:fd.get("video_url").trim(),kind:fd.get("kind"),genre:fd.get("genre"),year:fd.get("year")?Number(fd.get("year")):null,rating:fd.get("rating")?Number(fd.get("rating")):null,published:true};
 if(!configured()){row.id=Date.now();films.unshift(row);localStorage.setItem("damovies_demo_films",JSON.stringify(films));render();toast("Byabitswe muri demo browser gusa");e.target.reset();return}
 const {error}=await supabase.from("films").insert(row);if(error){toast("Ntibyabitswe: "+error.message);return}toast("Filime yongewemo");e.target.reset();await loadFilms();
}
async function deleteFilm(id){
 if(!confirm("Urashaka koko gusiba iyi filime?"))return;
 if(!configured()){films=films.filter(f=>String(f.id)!==String(id));localStorage.setItem("damovies_demo_films",JSON.stringify(films))}else{const {error}=await supabase.from("films").delete().eq("id",id);if(error){toast(error.message);return}await loadFilms()}
 closeModal("watchModal");toast("Filime yasibwe");renderAdmin();
}
})();