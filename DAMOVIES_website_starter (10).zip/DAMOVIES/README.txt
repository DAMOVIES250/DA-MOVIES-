# DAMOVIES — starter project

This is a responsive Kinyarwanda/English movie catalog website starter.

## What works now
- Responsive layout for phone and desktop
- Search, genre filters, movie/series filter
- Movie detail/player dialog
- Admin add-film form
- Demo mode saves sample entries only in the current browser's local storage

## To enable real online data and secure admin login (free starting tier)
1. Create a project at https://supabase.com/
2. In Supabase, open SQL Editor and run all of `supabase-setup.sql`.
3. In Authentication, create an admin user using an email and strong password.
4. Open that user's details and copy the user UUID.
5. In SQL Editor, run: `insert into public.admins (user_id) values ('YOUR-USER-UUID');`
6. In Project Settings → API, copy the Project URL and anon/public key.
7. Edit `config.js` and paste them into `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
   Never paste a `service_role` secret key into browser code.
8. Publish the folder to a static host such as GitHub Pages or Netlify.

## Free publishing
- GitHub Pages: create a GitHub repository, upload these files, then enable Pages in repository Settings.
- Netlify: create a site and upload the project folder, or connect the repository.
- The website is static; Supabase provides authentication and database.

## Important limitations / next production steps
- This starter stores video URLs; it does not upload large video files to a server.
- Use videos you own or have permission to distribute. For video uploads, connect a suitable video host/storage and implement signed upload policies.
- Free plans have limits and can change. Streaming large files may require paid bandwidth/storage.
- Paid viewing is not implemented yet. Payments require a provider, server-side verification, and legal/business setup.
- Do not use demo mode or demo PIN on a public production website.
- Test Supabase Row Level Security policies before launch.
